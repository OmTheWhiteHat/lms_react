import { getServerSession } from "next-auth/next"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default async function Dashboard() {
  const session = await getServerSession()
  if (!session) {
    redirect("/login")
  }

  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-6">Dashboard</h1>
      <div className="grid grid-cols-2 gap-4">
        <Link href="/dashboard/manage-devices">
          <Button className="w-full">Manage Devices</Button>
        </Link>
        <Link href="/dashboard/manage-items">
          <Button className="w-full">Manage Items</Button>
        </Link>
        <Link href="/dashboard/stock-details">
          <Button className="w-full">Stock Details</Button>
        </Link>
        <Link href="/dashboard/issue-requests">
          <Button className="w-full">Issue Requests</Button>
        </Link>
        <Link href="/dashboard/system-log">
          <Button className="w-full">System Log</Button>
        </Link>
        <Link href="/dashboard/print-receipt">
          <Button className="w-full">Print Receipt</Button>
        </Link>
      </div>
    </div>
  )
}

