import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function GET() {
  const devices = await prisma.device.findMany()
  return NextResponse.json(devices)
}

export async function POST(req: Request) {
  const { type, serialNumber, location } = await req.json()
  const device = await prisma.device.create({
    data: { type, serialNumber, location },
  })
  return NextResponse.json(device)
}

