"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"

export default function ManageDevices() {
  const [devices, setDevices] = useState([])
  const [newDevice, setNewDevice] = useState({ type: "", serialNumber: "", location: "" })

  useEffect(() => {
    // Fetch devices from API
    fetchDevices()
  }, [])

  const fetchDevices = async () => {
    const response = await fetch("/api/devices")
    const data = await response.json()
    setDevices(data)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch("/api/devices", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newDevice),
    })
    if (response.ok) {
      fetchDevices()
      setNewDevice({ type: "", serialNumber: "", location: "" })
    }
  }

  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-6">Manage Devices</h1>
      <form onSubmit={handleSubmit} className="mb-8">
        <Select
          value={newDevice.type}
          onChange={(e) => setNewDevice({ ...newDevice, type: e.target.value })}
          className="mb-4"
        >
          <option value="">Select Device Type</option>
          <option value="CPU">CPU</option>
          <option value="Monitor">Monitor</option>
          <option value="UPS">UPS</option>
        </Select>
        <Input
          type="text"
          placeholder="Serial Number"
          value={newDevice.serialNumber}
          onChange={(e) => setNewDevice({ ...newDevice, serialNumber: e.target.value })}
          className="mb-4"
        />
        <Input
          type="text"
          placeholder="Location"
          value={newDevice.location}
          onChange={(e) => setNewDevice({ ...newDevice, location: e.target.value })}
          className="mb-4"
        />
        <Button type="submit">Add Device</Button>
      </form>
      <div>
        <h2 className="text-2xl font-bold mb-4">Device List</h2>
        {devices.map((device: any) => (
          <div key={device.id} className="mb-2">
            {device.type} - {device.serialNumber} - {device.location}
          </div>
        ))}
      </div>
    </div>
  )
}

